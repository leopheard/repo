git init

git add .

git commit -m "upload"

git push -u origin master

read